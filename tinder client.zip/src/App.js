import React from 'react';
import './App.css';
import CCMainApp from './Component/CCMainApp';
import CCDetails from './Component/CCDetails';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import CCMatch from './Component/CCMatch';
import CCLiked from './Component/CCLiked';


function App() {
  return (
    <div className="App">
      <Switch>
        <Route exact path="/" component={CCMainApp} />
        <Route path="/details" component={CCDetails} />
        <Route path="/match" component={CCMatch} />
        <Route path="/Liked" component={CCLiked} />
      </Switch>
    </div>
  );
}

export default App;
