import React, { Component } from 'react';
import $ from 'jquery';
import CCOnelike from './CCOnelike'


export default class CCMatch extends Component {

  constructor(props) {
    super(props);

    let local = false;
    this.apiUrlLike = 'http://localhost:57269/api/Like';
    if (!local) {
      this.apiUrlLike = 'http://proj.ruppin.ac.il/igroup2/mobile/server/api/Like';
    }
    this.apiUrlUser = 'http://localhost:57269/api/User';
    if (!local) {
      this.apiUrlUser = 'http://proj.ruppin.ac.il/igroup2/mobile/server/api/User';
    }
    this.state = {
      arr: [],
      idLikes: [],
      st: [],
      empty: ""
    }
  }
  componentWillMount() {
    fetch(this.apiUrlLike, {
      method: 'GET',
      headers: new Headers({
        'Content-Type': 'application/json; charset=UTF-8',
      })
    })
      .then(res => {
        console.log('res=', res);
        console.log('res.status', res.status);
        console.log('res.ok', res.ok);
        return res.json()
      })
      .then(
        (result) => {
          console.log("fetch getLikesData= ", result);
          this.setState({ idLikes: result });
          this.setState({ empty : (this.state.idLikes.length == 0 ? "You did not liked anyone yet" : "") }); 
        },
        (error) => {
          console.log("err post=", error);
        });

    fetch(this.apiUrlUser, {
      method: 'GET',
      headers: new Headers({
        'Content-Type': 'application/json; charset=UTF-8',
      })
    })
      .then(res => {
        console.log('res=', res);
        console.log('res.status', res.status);
        console.log('res.ok', res.ok);
        return res.json()
      })
      .then(
        (result) => {
          console.log("fetch getUsersData= ", result);
          this.setState({ arr: result })
          for (let l = 0; l < this.state.idLikes.length; l++) {
            for (let i = 1; i <= this.state.arr.length; i++) {
              if (i == this.state.idLikes[l].LikeID) {
                console.log(this.state.arr[i - 1].UserName)
                var x = this.state.st;
                x.push(this.state.arr[i - 1]);
                this.setState({ st: x });
              }

            }
          }

        },
        (error) => {
          console.log("err post=", error);
        });

    console.log(this.state.arr);
    console.log(this.state.idLikes);
  }
  Home = () => {
    this.props.history.push({
      pathname: '/',
    })
  }


  render() {


    return (
      <div className='container-fluid col-md-12 containerStyle' >
        <div className="row">
          <div className="col md-10">
            <h1>The People You Liked:</h1>
          </div>
          <div className='col-md-2'>
            <button className='btn btn-danger' style={{ marginTop: '10px' }} onClick={this.Home}>Home</button>
          </div>
        </div>
        <div>{console.log(this.state.st.length)}</div>
        <div className="row">{
          this.state.st.map((item) =>
            <CCOnelike item={item} />
          )}</div>
        <div> <h2 style={{marginTop:'50px'}}> {(this.state.empty)}</h2></div>
      </div >
    )
  }
}