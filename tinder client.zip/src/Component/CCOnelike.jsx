import React, { Component } from 'react';
import $ from 'jquery';

export default class CCOnelike extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className='container-fluid col-md-4 containerStyle2' >
                <div><img style={ImgStyle} src={this.props.item.UserImage.toString()} /></div>
                <div>{this.props.item.UserName}</div>
                <div>Age: {this.props.item.UserAge}</div>
                <div>Height: {this.props.item.UserHeight}</div>
                <div>City: {this.props.item.UserCity}</div>
            </div>

        )
    }
}
const ImgStyle = {
    height: '200px',
    borderRadius: '40px',
    padding: '20px'
}