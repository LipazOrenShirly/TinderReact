import React, { Component } from 'react';
import $ from 'jquery';
import User from '../Class/User';

export default class CCDetails extends Component {
    constructor(props) {
        super(props);
        let local = false;
        this.apiUrl = 'http://localhost:57269/api/User';
        if (!local) {
            this.apiUrl = 'http://proj.ruppin.ac.il/igroup2/mobile/server/api/User';
        }
        this.state = {
            radioVal: "",
            fromInput: "",
            toInput: "",
            index: 0,
            resultData: []
        }

    }

    fromChange = (e) => {
        var n = e.target.value;
        this.setState({ fromInput: n })
    }
    toChange = (e) => {
        var n = e.target.value;
        this.setState({ toInput: n })
    }

    btnClicked = () => {

        var rv = $('input[name=radio]:checked').val();
        if (rv == null) {
            alert("please choose your partner gender");
            return;
        }
        else if (this.state.fromInput == "" || this.state.toInput == "") {
            alert("please choose between age")
            return;
        }
        else {
            var arr = [];
            console.log(this.state.resultData.length);
            for (let index = 0; index < this.state.resultData.length; index++) {
                if (rv == this.state.resultData[index].UserGender) {
                    if (this.state.fromInput < this.state.resultData[index].UserAge && this.state.toInput > this.state.resultData[index].UserAge) {

                        arr.push(new User(index + 1, this.state.resultData[index].UserName, this.state.resultData[index].UserGender, this.state.resultData[index].UserAge, this.state.resultData[index].UserHeight, this.state.resultData[index].UserCity, this.state.resultData[index].UserImage, this.state.resultData[index].UserPremium, this.state.resultData[index].UserHobbies));

                        //arr.push(this.state.resultData[index])
                    }
                }
            }
            console.log(arr);
            this.setState({
                radioVal: rv
            }, () =>
                this.props.history.push({
                    pathname: '/match',
                    state: { userObj: this.state, arr: arr }

                }))


        }
    }

    componentWillMount() {
        fetch(this.apiUrl, {
            method: 'GET',
            headers: new Headers({
                'Content-Type': 'application/json; charset=UTF-8',
            })
        })
            .then(res => {
                console.log('res=', res);
                console.log('res.status', res.status);
                console.log('res.ok', res.ok);
                return res.json()
            })
            .then(
                (result) => {
                    console.log("fetch getUsersData= ", result);
                    this.setState({ resultData: result })

                },
                (error) => {
                    console.log("err post=", error);
                });
    }





    render() {


        return (
            <div className='container-fluid col-md-12 containerStyle' >
                <div className="row" id="ph">
                    <div className="col-md-12"><h1 style={{marginTop:'30px'}}>Choose Partner Gender</h1></div>
                    <div className="col-md-12">
                        <label className="LableContainer">Male
                            <input type="radio" name="radio" value="Male" />
                            <span className="checkmark" style={{marginLeft:'380px'}}></span>
                        </label>
                        <label className="LableContainer" > Female
                            <input type="radio" name="radio" value="Female" />
                            <span className="checkmark" style={{marginLeft:'380px'}}> </span>
                        </label>
                    </div>
                    <div className="col-md-12"><h1>Choose Partner Age</h1></div>
                    <div className="col-md-12"><h3>Between</h3></div>
                    <div className="col-md-12"><input id="minInputText" className="inputText" type="text" name="from" onChange={this.fromChange} /></div>
                    <div className="col-md-12"><h3>And</h3></div>
                    <div className="col-md-12"><input id="maxInputText" className="inputText" type="text" name="to" onChange={this.toChange} /></div>
                    <div className="col-md-12" style ={{marginTop:'25px'}}>
                        <button className="main-button-slider btn btn-danger" onClick={this.btnClicked} id="find">Show My Options</button></div>
                </div></div>
        )
    }
}
