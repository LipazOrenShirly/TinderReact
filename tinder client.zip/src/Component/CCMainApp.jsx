import React, {Component} from 'react';
import $ from 'jquery';
import CCDetails from './CCDetails';


export default class CCMainApp extends Component{
    
    constructor(props){
        super(props);
        
    }
    btnClick=()=>{
          this.props.history.push({
              pathname:'/details',
          })           
     }
     btnClickLike=()=>{
        this.props.history.push({
            pathname:'/Liked',
        }) 
     }
    render(){
        
        
        return(
            <div className='container-fluid col-md-12 containerStyle'  >
            <div className="row col-md-12" id="ph">
            <div className="col-md-12" style={TinderStyle}>Tinder</div>
            <div className="col-md-12" style={wordsStyle}>Where your fingers deside your future</div>
            <div className="col-md-12" style={buttonStyle}><button id="buttonId" type="button" class="btn btn-danger" onClick={this.btnClick} style={{fontSize:'150%'}} >Start</button></div>
            <div className="col-md-12" style={buttonStyle}><button id="buttonId" type="button" class="btn btn-danger" onClick={this.btnClickLike} style={{fontSize:'150%'}} >Liked people</button></div>
            
        </div></div>
    )}
}



const TinderStyle={
    marginTop:'50px',
    fontSize:'400%',
    fontFamily:'Segoe UI Black',
    
    
   
}
const wordsStyle={
    fontSize:'200%'
}
const buttonStyle={
    marginTop:'20px',
    textAlign:'center', 
}