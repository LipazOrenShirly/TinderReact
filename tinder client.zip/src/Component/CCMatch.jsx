import React, { Component } from 'react';
import $ from 'jquery';

export default class CCMatch extends Component {

  constructor(props) {
    super(props);
    let local = false;
    this.apiUrl = 'http://localhost:57269/api/Like';
    if (!local) {
      this.apiUrl = 'http://proj.ruppin.ac.il/igroup2/mobile/server/api/Like';
    }
    this.state = {
      index1: this.props.location.state.userObj.index,
    }
  }

  NextUser = () => {
    if (this.props.location.state.arr.length == this.state.index1 + 1) {
      alert("there are no more matches to show");
      this.props.history.push({
        pathname: '/',
      })
    }
    else {
      var i = this.state.index1 + 1
      this.setState({ index1: i })
    }
  }
  Like = () => {
    var s = {
      LikeID: this.props.location.state.arr[this.state.index1].LikeID
    }
    fetch(this.apiUrl, {
      method: 'POST',
      body: JSON.stringify(s),
      headers: new Headers({
        'Content-type': 'application/json; charset=UTF-8'
      })
    })
      .then(res => {
        console.log('res=', res);
        return res.json()
      })
      .then(
        (result) => {
          console.log("fetch POST= ", result);

        },
        (error) => {
          console.log("err post=", error);
        });

    this.NextUser();


  }

  render() {
    return (
      <div className='container-fluid col-md-12 containerStyle' >
        {/* <div>{this.props.location.state.userObj.radioVal}</div> */}
        {/* <div>{this.props.location.state.userObj.fromInput}</div> */}
        {/* {this.props.location.state.userObj.toInput} */}
        <div> <h1>{this.props.location.state.arr[this.state.index1].name}</h1></div>
        <div><img style={ImgStyle} src={this.props.location.state.arr[this.state.index1].image.toString()} /></div>
        <div><h2>Age: {this.props.location.state.arr[this.state.index1].age}</h2></div>
        <div><h2>Height: {this.props.location.state.arr[this.state.index1].height}</h2></div>
        <div><h2>City: {this.props.location.state.arr[this.state.index1].city}</h2></div>
        {(this.props.location.state.arr[this.state.index1].premium == 1 ? <div><h2>Hobbies: {this.props.location.state.arr[this.state.index1].hobbies}</h2></div> : "")}
        <button className = 'btn btn-danger' onClick={this.NextUser}>Next</button>
        <button className = 'btn btn-danger' style={{marginLeft:'20px'}} onClick={this.Like}>Like</button>
      </div>
    )
  }
}

const ImgStyle = {
  height: '200px',
  borderRadius: '10px'
}



