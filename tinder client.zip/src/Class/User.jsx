import React from 'react';
export default class User {
    
    constructor( LikeID, name, gender, age, height, city, image, premium ,hobbies){
        this.LikeID=LikeID;
        this.name=name;
        this.gender=gender;
        this.age=age;
        this.height=height;
        this.city=city;
        this.image=image;
        this.premium=premium;
        this.hobbies=hobbies
    }

    

    render(){return(
    
          <div >
              User
       </div> 
    )}
}